from services import Executor


if __name__ == '__main__':
    executor = Executor()
    executor.execute()
