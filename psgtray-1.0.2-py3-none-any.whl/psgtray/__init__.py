name = "psgtray"
from .psgtray import *
from .psgtray import __version__
